package module;

public class Course {
}
