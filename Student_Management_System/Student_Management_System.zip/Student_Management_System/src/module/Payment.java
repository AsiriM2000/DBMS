package module;

public class Payment {
}
