package module;

public class Registration {
}
